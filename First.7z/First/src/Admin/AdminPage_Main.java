package Admin;

public class AdminPage_Main {

	public static void main(String[] args) {
		new AdminPage_Frame();
	}
}
