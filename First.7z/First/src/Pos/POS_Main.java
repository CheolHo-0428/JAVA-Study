package Pos;

import java.util.ArrayList;

import Pos.PosPanel.Information;

public class POS_Main {
	public static ArrayList<Information> sub = new ArrayList<Information>();
	public static void main(String[] args) {
		//ArrayList sub = new ArrayList();
		new PosFrame();
	}
}
